//  Copy List with Random Pointer
//链接：https://leetcode-cn.com/problems/copy-list-with-random-pointer/solution/c-by-eric-345-80/

class Solution {
public:
    //方法1
    Node* copyRandomList(Node* head)
    {
        if (head == nullptr)
            return head;

        //遍历原链表 创建新链表节点并建立映射关系
        unordered_map<Node*, Node*> map; //key: 原链表节点  value: 新创建节点 

        Node* cur = head;
        while (cur)
        {
            map[cur] = new Node(cur->val);
            cur = cur->next;
        }

        //遍历原链表 根据map找新链表的random
        cur = head;
        while (cur)
        {
            map[cur]->next = map[cur->next];
            map[cur]->random = map[cur->random];
            cur = cur->next;
        }

        return map[head];
    }

   
};


