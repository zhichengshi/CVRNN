//链接：https://leetcode-cn.com/problems/coin-change/solution/322-ling-qian-dui-huan-by-leetcode-solution/

class Solution {
    int coinChange(int idxCoin, vector<int>& coins, int amount) {
        if (amount == 0) return 0;
        if (idxCoin < coins.size() && amount > 0) {
            int maxVal = amount / coins[idxCoin];
            int minCost = INT_MAX;
            for (int x = 0; x <= maxVal; x++) {
                if (amount >= x * coins[idxCoin]) {
                    int res = coinChange(idxCoin + 1, coins, amount - x * coins[idxCoin]);
                    if (res != -1) minCost = min(minCost, res + x);
                }
            }
            return minCost == INT_MAX ? -1: minCost;
        }
        return -1;
    }
public:
    int coinChange(vector<int>& coins, int amount) {
        return coinChange(0, coins, amount);
    }
};

