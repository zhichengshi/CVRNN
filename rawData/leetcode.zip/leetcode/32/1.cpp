//链接：https://leetcode-cn.com/problems/maximal-square/solution/221-by-animalcoder/

class Solution {
public:
    int dp[2][5005];//dp[i][j]以(i,j)为右下角的最大正方形宽度，节省空间滚动一下
    int maximalSquare(vector<vector<char>>& matrix) {
        int n=matrix.size();if(n==0)return 0;
        int m=matrix[0].size();
        int ans=0;
        
        for(int i=1,t=0;i<=n;i++,t^=1){
            for(int j=1;j<=m;j++){
                if(matrix[i-1][j-1]=='1')
                    dp[t][j]=min(dp[t^1][j-1],min(dp[t][j-1],dp[t^1][j]))+1;
                else dp[t][j]=0;
                ans=max(dp[t][j],ans);
            }
        }
        return ans*ans;
    }

};
