//22. Generate Parentheses
//链接：https://leetcode-cn.com/problems/generate-parentheses/solution/zui-ji-ben-de-dfs-by-chengm15/

class Solution {
public:
    vector<string> generateParenthesis(int n) {
        vector<string> res;
        func(res, "", n, n);
        return res;
    }

    void func(vector<string> &res, string str, int l, int r){
        if(l == 0 && r == 0){
            res.push_back(str);
            return;
        }
        if(l > 0){
            func(res, str + '(', l-1, r);
        }
        if(r > 0 && r > l){
            func(res, str + ')', l, r-1);
        }
        return;
    }
};