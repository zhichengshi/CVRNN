//22. Generate Parentheses
//链接：https://leetcode-cn.com/problems/generate-parentheses/solution/di-gui-fa-by-mooc-3/

class Solution {
public:
    void digui(string & t,int lec,int ric,int n,vector<string>& res)
    {
        if(lec==n)
        {
            res.push_back(t+string(n-ric,')'));
            return;
        }
        t.push_back('(');
        digui(t,lec+1,ric,n,res);
        t.erase(lec+ric,1);
        if(ric<lec)
        {
            t.push_back(')');
            digui(t,lec,ric+1,n,res);
            t.erase(lec+ric,1);
        }
    }
    vector<string> generateParenthesis(int n) 
    {
        vector<string> res;
        string t;
        digui(t,0,0,n,res);
        return res;
    }
};
