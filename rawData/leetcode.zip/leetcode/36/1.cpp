//链接：https://leetcode-cn.com/problems/verify-preorder-serialization-of-a-binary-tree/solution/c-shuang-100zhan-wei-fu-by-cctreasure/

class Solution {
public:
    bool isValidSerialization(string preorder) {
        if (preorder.empty()) return false;
        stack<bool> s;
        for (int i = 0; i < preorder.size(); ++i) {
            if (preorder[i] == '#') {
                if (s.empty()) return i == preorder.size() - 1;
                else {
                    s.pop();
                    i++;
                }
            }
            else {
                while (i < preorder.size() && preorder[i] != ',') i++;
                s.push(0);
            }
        }
        return false;
    }
};
