//链接：https://leetcode-cn.com/problems/verify-preorder-serialization-of-a-binary-tree/solution/bu-fen-ge-zi-fu-chuan-zhan-by-gorgeousyurou/

class Solution {
public:
    bool isValidSerialization(string preorder) {
        int n = preorder.length();
        stack<int> s;
        //flag用于标记子树是否遍历完成
        int flag=1;
        for(int i=0;i<n;i++){
            //字符串未结束，但已经遍历完前序序列
            if(flag==0) return false;
            //如果为非空结点，则push
            if(preorder[i]!='#'){
                while(i<n && preorder[i]!=','){
                    i++;
                }
                //push(1)标记push结点
                s.push(1);
            }
            else{
                i++;//去掉逗号
                //遍历完某颗子树，置flag=0
                if(flag) flag=0;
                //左子树为空，弹出根
                if(!s.empty()) {
                    s.pop();
                    flag=1;
                }
                
            }
        }
        if((s.empty())&&(!flag)) return true;
        else return false;    
    }
    
    
};

