//Clone Graph  
//链接：https://leetcode-cn.com/problems/clone-graph/solution/shen-du-you-xian-di-gui-fei-di-gui-he-yan-du-you-x/

Node* cloneGraphDfs(Node* node)
{
    if (!node) return nullptr;
    unordered_map<Node*, Node*>mp;
    stack<Node*> st({ node });
    const auto new_node = new Node(node->val);
    mp[node] = new_node;
    while (!st.empty()) {
        const auto temp = st.top();
        st.pop();
        for (const auto&e : temp->neighbors) {
            if(!mp.count(e)) {
                st.push(e);
                mp[e] = new Node(e->val);
            }
            mp[temp]->neighbors.push_back(mp[e]);
        }
    }
    return mp[node];
}


