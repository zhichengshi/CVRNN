//Search in Rotated Sorted Array  
// 链接：https://leetcode-cn.com/problems/search-in-rotated-sorted-array/solution/zai-shu-zu-zhong-ren-yi-wei-zhi-kan-yi-dao-yi-ding/


class Solution {
public:
    int search(vector<int>& nums, int target) {
        int res = -1, l = 0, r = nums.size() - 1;
        while(l <= r){
            int mid = (l+r)/2;
            if(nums[mid] > nums[r]){
                //[mid,r] is non-sorted, [l, mid] is sorted
                // 说明数组一定不是sorted，只要不是sorted必定有A[l] > A[r]
                if(target == nums[mid]){
                    return mid;
                }else if(target > nums[mid]){
                    // A[mid] > A[l]，说明target只可能在mid的右边
                    l = mid+1; 
                }else{//target < nums[mid]
                    if(target > nums[r]){
                        // 说明只可能在[l,mid]中，[l,mid]为sorted，直接二分查找
                        return searchSortedArray(nums, l, mid-1, target);
                    }else if(target == nums[r]){
                        return r;
                    }else{
                        // target < nums[r]
                        // 说明只可能在[mid, r]
                        l = mid + 1;
                    }
                }
            }else{
                //[mid, r] is sorted
                if(target >= nums[mid] && target <= nums[r]){
                    return searchSortedArray(nums, mid, r, target);
                }else{
                    r = mid - 1;
                }
            }
        }
        return res;
    }
    int searchSortedArray(vector<int>& nums, int l, int r, int target){
        while(l <= r){
            int mid = (l+r)/2;
            if(nums[mid] == target){
                return mid;
            }else if(nums[mid] > target){
                r = mid - 1;
            }else{
                l = mid + 1;
            }
        }
        return -1;
    }
};
