//Search in Rotated Sorted Array  
//


public static class Solution {
    public int search(int[] nums, int target) {
        int left = 0;
        int right = nums.length;
        while (left < right) {
            int pivot = (right - left) / 2 + left;
            if (nums[pivot] == target) {
                return pivot;
            } else if (nums[pivot] < target) {
                // pivot值小了，直觉是向右查找，但是有一种情况例外：pivot落在右侧，并且最右端小于目标值。这种情况应该到左边查找
                if (nums[pivot] < nums[0] && nums[right - 1] < target) {
                    right = pivot;
                } else {
                    left = pivot + 1;
                }
            } else {
                // pivot值大了，直觉是向左查找。但是有一种情况例外：pivot落在左侧，并且最左端大于目标值。这种情况应该到右边查找
                if (nums[pivot] > nums[0] && nums[left] > target) {
                    left = pivot + 1;
                } else {
                    right = pivot;
                }
            }
        }
        return -1;
    }
}