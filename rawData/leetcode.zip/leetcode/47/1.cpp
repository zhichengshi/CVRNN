//链接：https://leetcode-cn.com/problems/top-k-frequent-elements/solution/c-xiao-gen-dui-qiu-qian-kda-by-zhengguanyu/

class Solution {
public:
    vector<int> topKFrequent(vector<int>& nums, int k) {
         
        unordered_map<int,int> record;  //(元素，频率)
        //遍历数组，录入频率
        for(int i = 0; i < nums.size(); i++){
            record[nums[i]]++;
        }
        int n = record.size();
         
        vector<int> result;
        if(n != k){ // 如果 n == k，根据题意，直接统计 record 中的元素就好了
             
            //扫描record。维护当前出现频率最少的n-k个元素
            //最大堆。如果当前元素的频率小于优先队列中最大频率元素的频率，则替换
            //优先队列中，按频率排序，所以数据对是(频率，元素)形式
            priority_queue< pair<int,int> > pq;
            for(auto iter = record.begin(); iter != record.end(); iter++){
                if((n - k) == (int)pq.size()){ //队列已满
                    if(iter->second < pq.top().first){
                        pq.pop();
                        pq.push(make_pair(iter->second,iter->first));
                    }
                }
                else{
                    pq.push(make_pair(iter->second,iter->first));
                }
            }
         
            while(!pq.empty()){
                record.erase(pq.top().second);
                pq.pop();
            }
        }
         
        for(auto iter : record){
            result.push_back(iter.first);
        }
        return result;
    }
};

