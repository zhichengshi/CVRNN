// Unique Paths II
//链接：https://leetcode-cn.com/problems/unique-paths-ii/solution/he-shang-yi-ti-de-qu-bie-jia-ru-liao-obstaclegridi/

class Solution {
public:
    int uniquePathsWithObstacles(vector<vector<int>>& obstacleGrid) {
        if(obstacleGrid.size() == 0 || obstacleGrid[0].size() == 0) return 0;
        if(obstacleGrid.back().back() == 1) return 0;
        int m = obstacleGrid[0].size(), n = obstacleGrid.size();
        vector<long> tmp(m, 0);
        vector<vector<long>> dp(n, tmp);
        dp[0][0] = 1;
        for(int i = 0; i < n; ++i){
            for(int j = 0; j < m; ++j){
                //cout << i << " " << j << endl;
                if(i == 0 && j == 0) continue;
                long val1, val2;
                if(i == 0 || obstacleGrid[i-1][j] == 1){
                    val1 = 0;
                }else{
                    val1 = dp[i-1][j];
                }
                if(j == 0 || obstacleGrid[i][j-1] == 1){
                    val2 = 0;
                }else{
                    val2 = dp[i][j-1];
                }
                dp[i][j] = val1 + val2;
            }
        }
        return dp.back().back();
    }
};

