//链接：https://leetcode-cn.com/problems/one-away-lcci/solution/cshuang-zhi-zhen-by-leed_anlin/

class Solution {
public:
    bool oneEditAway(string first, string second) {
        int opt; // 1-delete  0-updata 2-insert
        int d = first.size() + second.size() -min(first.size(),second.size()) * 2;
        if(d>1) return false;
        else{
            if(first.size()>second.size()) opt = 1;
            else if(first.size()==second.size()) opt = 0;
            else opt=2;
        }
        int edit_dis = 0;
        for(int i=0,j=0;i<first.size()&&j<second.size();i++,j++){
            if(first[i]!=second[j]){
                edit_dis++;
                if(opt==1)
                {
                    j--;
                }
                if(opt==2)
                {   
                    i--;
                }
            }
        }
        return edit_dis<=1;
    }
};

