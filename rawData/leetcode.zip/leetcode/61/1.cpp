//链接：https://leetcode-cn.com/problems/one-away-lcci/solution/c-shuang-bai-jie-fa-bian-ji-ju-chi-shuang-zhi-zhen/

class Solution {
public:
  bool oneEditAway(string first, string second) {
    int len1 = first.size(), len2 = second.size();
    if (abs(len1 - len2) > 1) return false;
    vector<vector<int>> dp(len1+1, vector<int>(len2+1, 0));
    for (int i = 1; i <= len1; i++) dp[i][0] = i;
    for (int j = 1; j <= len2; j++) dp[0][j] = j;
    for (int i = 1; i <= len1; i++) {
      for (int j = 1; j <= len2; j++) {
        if (first[i-1] == second[j-1]) {
          dp[i][j] = min(dp[i-1][j-1], min(dp[i][j-1] + 1, dp[i-1][j] + 1));
        } else {
          dp[i][j] = min(dp[i-1][j-1] + 1, min(dp[i][j-1] + 1, dp[i-1][j] + 1));
        }
      }
    }
    return dp[len1][len2] <= 1;
  }
};
