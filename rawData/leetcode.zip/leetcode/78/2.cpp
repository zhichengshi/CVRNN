//链接：https://leetcode-cn.com/problems/find-the-town-judge/solution/c-dan-ge-shu-zu-by-symmetric/

class Solution {
public:
    int findJudge(int N, vector<vector<int>>& trust) {
        int trustCollector[N + 1] = {0};
        int the_one_most_trusted = 1;
        int highest_trust_num = 0;

        for (int i = 0; i < trust.size(); i++)
        {
            ++trustCollector[trust[i][1]];
            --trustCollector[trust[i][0]];
        }

        for (int i = 1; i < N + 1; i++)
        {
            if (trustCollector[i] > highest_trust_num)
            {
                highest_trust_num = trustCollector[i];
                the_one_most_trusted = i;
            }
        }
        return highest_trust_num == N - 1 ? the_one_most_trusted : -1;
    }
};

