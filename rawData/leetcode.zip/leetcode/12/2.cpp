//链接：https://leetcode-cn.com/problems/find-largest-value-in-each-tree-row/solution/cpp-yan-du-you-xian-sou-suo-by-xu-zhou-geng/

class Solution {
public:
    vector<int> largestValues(TreeNode* root) {
        vector<int> res;
        if (root == NULL) return res;

        queue<TreeNode*> myque;
        myque.push(root);

        while ( ! myque.empty() ){
            int level_size = myque.size();
            int max = INT_MIN;
            for (int i = 0; i < level_size; i++){
                TreeNode *node = myque.front();
                myque.pop();
                max = node->val > max ? node->val : max;

                if (node->left != NULL) myque.push(node->left);
                if (node->right != NULL) myque.push(node->right); 
            }
            res.push_back(max);
        }
        return res;

    }
};

