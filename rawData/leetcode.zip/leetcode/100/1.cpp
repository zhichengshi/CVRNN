//链接：https://leetcode-cn.com/problems/occurrences-after-bigram/solution/shi-jian-he-kong-jian-fu-za-du-du-shi-onde-cjie-fa/

class Solution {
public:
    vector<string> findOcurrences(string text, string first, string second) {
        
        
        string temp;
        
        vector<string> pool;
        vector<string> output;
        
        for(int i=0; i<=text.length(); i++){//先把text以" "为分隔拆分成一组vector
            
            if(text[i]!=' ' && text[i]!='\0'){
                
                temp.push_back(text[i]);
            }
            else{
                pool.push_back(temp);
                temp = "";
            }
        }
        
        for(int i=0; i+1<pool.size(); i++){//遍历重组的vecotr 保存first和second后面的那个字符串
            
            if(pool[i]==first && pool[i+1]==second && i+2<pool.size())
                output.push_back(pool[i+2]);
        }
        
        
        
        return output;
        
    }
};

