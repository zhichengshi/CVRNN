//Swap Nodes in Pairs  
//链接：https://leetcode-cn.com/problems/swap-nodes-in-pairs/solution/die-dai-di-gui-by-24shi-01fen-_00_01/

class Solution {
public:
    ListNode* swapPairs(ListNode* head) {
        ListNode* res=new ListNode(0),*sp=res;
        while(head!=NULL&&head->next!=NULL){
            ListNode* tmp=head->next->next;
            sp->next=head->next;
            head->next->next=head;
            sp=sp->next->next;
            head=tmp;
        }
        if(head!=NULL) sp->next=head;
        else sp->next=NULL;
        return res->next;
    } 
};