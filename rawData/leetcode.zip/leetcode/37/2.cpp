//Swap Nodes in Pairs  
//链接：https://leetcode-cn.com/problems/swap-nodes-in-pairs/solution/die-dai-di-gui-by-24shi-01fen-_00_01/


class Solution {
public:
    ListNode* swapPairs(ListNode* head) {
        ListNode *res = new ListNode(0),*tmp = res;
        res->next = head;
        while(tmp->next != NULL && tmp->next->next != NULL) {
            ListNode *start = tmp->next,*end = tmp->next->next;
            tmp->next = end;
            start->next = end->next;
            end->next = start;
            tmp = start;
        }
        return res->next;
    }
};
