//链接：https://leetcode-cn.com/problems/er-cha-shu-de-zui-jin-gong-gong-zu-xian-lcof/solution/er-cha-shu-de-zui-jin-gong-gong-zu-xian-di-gui-b-2/

class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        //先找到p或者q就返回
        if(root == NULL || root == p || root == q) return root;
        //在左子树找p或q，假如p和q都在左子树，返回的那个值就是祖先
        TreeNode *left = lowestCommonAncestor(root->left, p, q);
        //在右子树找p或者q，假如p和q都在右子树，返回的那个值就是祖先
        TreeNode *right = lowestCommonAncestor(root->right, p, q);
        if(left == NULL) return right;
        if(right == NULL) return left;
        // p和q一个在左子树一个在右子树
        return root;
    }
};
