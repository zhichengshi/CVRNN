//链接：https://leetcode-cn.com/problems/implement-magic-dictionary/solution/cha-xi-biao-setjie-jue-su-du-chao-guo-86-by-c-bee-/

class MagicDictionary {
private:
    unordered_map<string, int> magicDict;
    unordered_set<string> originlDict;
public:
    /** Initialize your data structure here. */
    MagicDictionary() {
        
    }
    
    /** Build a dictionary through a list of words */
    void buildDict(vector<string> dict) {
        for(auto &dic : dict) {
            originlDict.insert(dic);
            char tmp;
            for(int i = 0; i < dic.length(); i++) {
                tmp = dic[i]; dic[i] = '!';
                magicDict[dic]++;
                dic[i] = tmp;
            }
        }
    }
    
    /** Returns if there is any word in the trie that equals to the given word after modifying exactly one character */
    bool search(string word) {
        char tmp, cnt = 0;
        for(int i = 0; i < word.length(); i++) {
            tmp = word[i]; word[i] = '!';
            if(cnt < magicDict[word]) cnt = magicDict[word];
            word[i] = tmp;
        }
        if(cnt == 0 || (cnt == 1 && originlDict.find(word) != originlDict.end())) return false;
        return true;
    }
};
