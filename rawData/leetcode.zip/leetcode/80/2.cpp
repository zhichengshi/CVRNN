//链接：https://leetcode-cn.com/problems/split-a-string-in-balanced-strings/solution/csexy-code-xiang-xi-ti-jie-by-youlookdeliciousc/

class Solution {
public:
    int balancedStringSplit(string s) {
        int ans = 0, l = 0, r = 0;
        for(char i : s){ // 遍历
            if(l == 0 && r == 0) i == 'L' ? ++ l: ++ r;
            else if(l > 0)  i == 'L' ? ++ l : -- l;
            else if(r > 0)  i == 'R' ? ++ r: -- r;
            if(l == 0 && r == 0)    ++ ans;
        }
        return ans;
    }
};

