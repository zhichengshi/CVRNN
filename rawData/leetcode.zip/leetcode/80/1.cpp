//链接：https://leetcode-cn.com/problems/split-a-string-in-balanced-strings/solution/csexy-code-xiang-xi-ti-jie-by-youlookdeliciousc/

class Solution {
public:
    int balancedStringSplit(string s) {
        int ans = 0, flag = 0;
        for(char i : s){ // 遍历
            i == 'L'? ++ flag: -- flag;
            if(flag == 0)   ++ ans;
        }
        return ans;
    }
};
