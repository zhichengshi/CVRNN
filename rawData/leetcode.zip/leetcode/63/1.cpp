//链接：https://leetcode-cn.com/problems/the-masseuse-lcci/solution/dong-tai-gui-hua-he-zhu-zhan-198house-robber-yi-ya/

class Solution {
public:
    int massage(vector<int>& nums) {
        if (nums.empty()) return 0;
        auto sz = nums.size();
        if (sz == 1) return nums[0];
        auto prev = nums[0];
        auto cur = max(prev, nums[1]);
        for (auto i = 2; i < sz; ++i) {
            auto tmp = cur;
            cur = max(nums[i] + prev, cur);
            prev = tmp;
        }
        return cur;
    }
};

