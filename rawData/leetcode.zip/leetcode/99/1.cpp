//链接：https://leetcode-cn.com/problems/play-with-chips/solution/-wan-chou-ma-by-hareyukai/

class Solution {
public:
    int minCostToMoveChips(const vector<int>& chips) {
        unsigned odds = 0;
        unsigned evens = 0;
        for (const auto chip : chips)
            chip & 0x1 ? ++odds : ++evens;
        return min(odds, evens);
    }
};

