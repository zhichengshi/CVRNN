//链接：https://leetcode-cn.com/problems/two-city-scheduling/solution/liang-di-diao-du-zhi-you-hua-suan-fa-by-yi-di-ji-m/

class Solution {
public:
    int twoCitySchedCost(vector<vector<int>>& costs) {
        int ans=0;
        vector<int> diff;
        for(int i=0;i<costs.size();i++){
            diff.push_back(costs[i][0]-costs[i][1]);
        }
        sort(diff.begin(),diff.end());
        for(int i=0;i<diff.size();i++){
            ans = ans + costs[i][1];
            if(i<diff.size()/2){
                ans=ans+diff[i];
            }
        }
        return ans;
        
    }
};
