//链接：https://leetcode-cn.com/problems/range-sum-query-mutable/solution/xian-duan-shu-by-drinkcola/

class NumArray {
public:
    vector<int> sum,*nums;
    int n;
    void build(int o,int l,int r){
        if(l==r){
            sum[o]=(*nums)[l];
            return;
        }
        int mid=l+r>>1;
        build(o<<1,l,mid);
        build(o<<1|1,mid+1,r);
        sum[o]=sum[o<<1]+sum[o<<1|1];
    }
    void modify(int o,int l,int r,int x,int v){
        if(l==r){
            sum[o]=v;
            return;
        }
        int mid=l+r>>1;
        if(x<=mid)modify(o<<1,l,mid,x,v);
        else modify(o<<1|1,mid+1,r,x,v);
        sum[o]=sum[o<<1]+sum[o<<1|1];
    }
    int query(int o,int l,int r,int x,int y){
        if(x<=l&&y>=r)return sum[o];
        int mid=l+r>>1,ans=0;
        if(x<=mid)ans+=query(o<<1,l,mid,x,y);
        if(y>mid)ans+=query(o<<1|1,mid+1,r,x,y);
        return ans;
    }
    // 4倍大小
    NumArray(vector<int>& nums):n(nums.size()),sum(nums.size()<<2) {
        this->nums=&nums;
        if(n)build(1,0,n-1);
    }
    
    void update(int i, int val) {
        modify(1,0,n-1,i,val);
    }
    
    int sumRange(int i, int j) {
        return query(1,0,n-1,i,j);
    }
};

