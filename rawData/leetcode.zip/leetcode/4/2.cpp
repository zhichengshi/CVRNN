//链接：https://leetcode-cn.com/problems/range-sum-query-mutable/solution/xian-duan-shu-by-drinkcola/

class NumArray {
public:
    vector<int> lc,rc,sum,*nums;
    int node_tot=0,root;
    int n;
    void build(int &o,int l,int r){
        o=++node_tot;
        if(l==r){
            sum[o]=(*nums)[l];
            return;
        }
        int mid=l+r>>1;
        build(lc[o],l,mid);
        build(rc[o],mid+1,r);
        sum[o]=sum[lc[o]]+sum[rc[o]];
    }
    void modify(int o,int l,int r,int x,int v){
        if(l==r){
            sum[o]=v;
            return;
        }
        int mid=l+r>>1;
        if(x<=mid)modify(lc[o],l,mid,x,v);
        else modify(rc[o],mid+1,r,x,v);
        sum[o]=sum[lc[o]]+sum[rc[o]];
    }
    int query(int o,int l,int r,int x,int y){
        if(x<=l&&y>=r)return sum[o];
        int mid=l+r>>1,ans=0;
        if(x<=mid)ans+=query(lc[o],l,mid,x,y);
        if(y>mid)ans+=query(rc[o],mid+1,r,x,y);
        return ans;
    }
    // 数组都开2倍大小，动态开点
    NumArray(vector<int>& nums):n(nums.size()),lc(nums.size()<<1),rc(nums.size()<<1),sum(nums.size()<<1) {
        this->nums=&nums;
        if(n)build(root,0,n-1);
    }
    
    void update(int i, int val) {
        modify(root,0,n-1,i,val);
    }
    
    int sumRange(int i, int j) {
        return query(root,0,n-1,i,j);
    }
};
