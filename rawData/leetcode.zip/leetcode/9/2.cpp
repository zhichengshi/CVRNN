//palindrome partitioning
//链接：https://leetcode-cn.com/problems/palindrome-partitioning/solution/hui-su-suan-fa-by-mrsate/

class Solution {
public:
    vector<vector<string>> res;
    vector<vector<string>> partition(string s) {
        vector<string> tmp;
        __partition(s, 0, tmp);
        return res;
    }
private:
    // 从字符串 s ， start 位置（包括）开始， 逐个检查 sub ∈ s[start, end] 是否是回文字符串， 是则放入 tmp， 并递归。
    void __partition(string s, int start, vector<string> tmp){
        if(start == s.size()){
            res.push_back(tmp);
        }
        for(int end = start; end < s.size(); end++){
            if(is_partition(s, start, end)){
                tmp.push_back(s.substr(start, end - start + 1));
                __partition(s, end + 1, tmp); // 从 start 位置开始检查， 如果 end 不去 + 1 那么该产生重复的检查
                tmp.pop_back();
            }
        }
    }
    
    // 检查 sub ∈ s [start, ..., end] 位置的元素是否是回文串
    bool is_partition(string s, int start, int end){
        for(int i = start, j = end; i <= j; i++, j--)
            if(s[i] != s[j])
                return false;
        return true;
   
