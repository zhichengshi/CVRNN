//Restore IP Addresses  
//链接：https://leetcode-cn.com/problems/restore-ip-addresses/solution/93-dfsjian-zhi-by-chengm15/

class Solution {
public:
    vector<string> restoreIpAddresses(string s) {
        vector<string> res;
        vector<string> tmp;
        if(s.size() > 12 || s.size() < 4) return res;
        getCombination(res, tmp, s, 0);
        return res;
    }

    void getCombination(vector<string> &res, vector<string> &tmp, string &s, int idx){
        if(tmp.size() == 4 && idx == s.size()){
            string str = tmp[0] + '.' + tmp[1] + '.' + tmp[2] + '.' + tmp[3];;
            res.push_back(str);
            return;
        }else{
            int remain_str = s.size() - idx;
            int remain_addr_part = 4 - tmp.size();
            if(remain_addr_part > remain_str || remain_addr_part * 3 < remain_str) return;
            //cout << "idx: " << idx << " remain_str: " << remain_str << " remain_addr_part: " << remain_addr_part << endl; 
            for(int i = 0; i < 3; ++i){
                string new_str;
                if(s[idx] == '0'){
                    new_str += s[idx];
                    if(i > 0){
                        break;
                    }
                }else{
                    new_str = s.substr(idx, i+1);
                    //cout << "new_str: " << new_str << endl;
                    if(i == 2){
                        int val = getThreeCharVal(new_str);
                        //cout << val << endl;
                        if(val > 255) break;
                    }
                }
                tmp.push_back(new_str);
                getCombination(res, tmp, s, idx+i+1);
                tmp.pop_back();
            }
        }
    }

    int getThreeCharVal(string str){
        int res = 0;
        res += (str[0] - '0') * 100;
        res += (str[1] - '0') * 10;
        res += (str[2] - '0');
        return res;
    }
};

