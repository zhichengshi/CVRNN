//  Gray Code
// 链接：https://leetcode-cn.com/problems/gray-code/solution/zhi-xing-yong-shi-nei-cun-xiao-hao-ji-bai-liao-1-5/

class Solution {
public:
    vector<int> grayCode(int n) {
        int shift = 1;
        vector<int> res;
        while(n >= 0){
            if(res.size() == 0){
                res.push_back(0);
            }else{
                for(int i = shift-1; i >= 0; --i){
                    res.push_back(res[i] + shift);
                }
                shift *= 2;
            }
            --n;
        }
        return res;
    }
};

