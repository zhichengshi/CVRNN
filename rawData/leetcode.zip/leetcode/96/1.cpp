//链接：https://leetcode-cn.com/problems/distribute-candies-to-people/solution/c-shuang-bai-si-lu-deng-chai-shu-lie-by-fxxuuu/

class Solution {
public:
  vector<int> distributeCandies(int candies, int num_people) {
    if (num_people == 0) return {};
    vector<int> ans(num_people, 0);
    if (candies == 0) return ans;
    int total_line = 0, t = 1;
    while (true) {
      int target = (t * num_people + 1) * t * num_people / 2;
      if (candies > target) {
        total_line++, t++;
      } else {
        break;
      }
    }
    if (total_line > 0) {
      for (int i = 1; i <= num_people; i++) {
        ans[i-1] = ((total_line - 1) * num_people + 2 * i) * total_line / 2;
      }
    }
    candies -= ((t-1) * num_people + 1) * (t-1) * num_people / 2;
    cout<<candies<<endl;
    int cur = total_line * num_people + 1;
    int ind = 0;
    while (candies > cur) {
      ans[ind++] += cur;
      candies -= cur;
      cur++;
    }
    ans[ind] += candies;
    return ans;
  }
};

