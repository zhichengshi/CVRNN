// Gas Station
//链接：https://leetcode-cn.com/problems/gas-station/solution/c-shuang-zhi-zhen-jian-ji-yi-dong-mo-ni-xun-huan-s/

class Solution {
public:
    int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
	if (gas.size() == 1)
		return gas[0] >= cost[0] ? 0 : -1;
	int gas_sum = accumulate(gas.begin(), gas.end(),0);//0为累加的初值
	int cost_sum = accumulate(cost.begin(), cost.end(), 0);
	if (gas_sum < cost_sum )//这里进行初始判断，如果总汽油量小于总花费量直接返回-1.
		return -1;
	int left = 0;//由于条件以满足，故left可以任意赋初值。
	int right = 1;
	int temp = gas[left]-cost[left];
    int N=gas.size();
	while (right != left)
	{
		if (temp >= 0)
		{
			temp += gas[right] - cost[right];//这里要先加再改right，因为之前还没有加
			right = right == N - 1 ? 0 : right + 1;
		}
		else
		{
			left = left == 0 ? N - 1 : left - 1;//这里要先改left再加。
			temp += gas[left] - cost[left];
		}
	}
	return left;
}
};

