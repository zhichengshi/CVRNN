// Gas Station
//链接：https://leetcode-cn.com/problems/gas-station/solution/c-shuang-zhi-zhen-jian-ji-yi-dong-mo-ni-xun-huan-s/

int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
	vector<int> diff;
	int max = gas[0] - cost[0];
	int max_idx = 0;
	for (int i = 0; i < gas.size(); i++)
	{
		diff.push_back(gas[i] - cost[i]);
		if (diff[i] > max)
		{
			max = diff[i];
			max_idx = i;
		}
	}
	if (max < 0)
		return -1;
	int left = max_idx;
	int right = left == diff.size() - 1 ? 0 : left + 1;
	int temp=diff[left] + diff[right];
	while (right != left)
	{
		if (temp >= 0)
		{
			right = right == diff.size() - 1 ? 0 : right + 1;
			temp += diff[right];
		}
		else
		{
			left = left == 0 ? diff.size() - 1 : left - 1;
			temp += diff[left];
		}
	}
	return temp >= 0?left:-1;
}

