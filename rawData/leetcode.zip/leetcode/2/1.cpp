'面试题13. 机器人的运动范围'
class Solution {
public:
    int movingCount(int m, int n, int k) {
        std::vector<std::vector<bool>> visit(m, std::vector<bool>(n, false));
        int c = 0;
        std::queue<std::pair<int, int>> que;
        //(0,0)初始化队列
        std::pair<int, int> p = std::make_pair(0, 0);
        que.push(p);
        //true初始化标志数组
        visit[p.first][p.second] = true;
        bfs(m, n, k, c, visit, que);
        return c;
    }

private:
    int sum(int n) {
        int s = 0;
        while (n > 0){
            s += n%10;
            n /= 10;
        }

        return s;
    }

    void bfs(int m, int n, int k, int &count, std::vector<std::vector<bool>> &visit,
    std::queue<std::pair<int, int>> &que) {
        std::pair<int, int> p(0, 0);
        while (!que.empty()) {
            //取出队首节点
            p = que.front();
            que.pop();
            //将计数+1
            count++;
            if (p.first + 1 >= 0 && p.first + 1 < m && p.second >= 0 && p.second < n &&
                sum(p.first + 1) + sum(p.second) <= k && !visit[p.first + 1][p.second]) {
                que.push({p.first + 1, p.second});
                visit[p.first + 1][p.second] = true;
            }

            if (p.first >= 0 && p.first < m && p.second + 1 >= 0 && p.second + 1 < n &&
                sum(p.first) + sum(p.second + 1) <= k && !visit[p.first][p.second + 1]) {
                que.push({p.first, p.second + 1});
                visit[p.first][p.second + 1] = true;
            }
        }
    }
}
