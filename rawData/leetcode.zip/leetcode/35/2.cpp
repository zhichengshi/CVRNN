//链接：https://leetcode-cn.com/problems/find-peak-element/solution/er-fen-cha-zhao-han-shu-dan-diao-xing-by-caesar989/

class Solution {
public:
int findPeakElement(vector<int>& nums) {
    if(nums.size() < 2) //只有一个元素
        return 0;
    if(nums[0] > nums[1]) //峰值在边界上
        return 0;
    if(nums[nums.size() - 1] > nums[nums.size() - 2])
        return nums.size() - 1;
        
    int i = 0;
    int j = nums.size() - 1;
    while(i < j){
        int mid = i + (j - i) / 2;
        if(nums[mid] > nums[mid + 1] && nums[mid] > nums[mid - 1])
            return mid;
        
        if(nums[mid] < nums[mid + 1])
            i = mid;
        else
            j = mid;
    }
    
    return -1;
}


};

