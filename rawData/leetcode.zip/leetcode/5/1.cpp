//链接：https://leetcode-cn.com/problems/majority-element-ii/solution/229-qiu-zhong-shu-iiboyer-mooretou-piao-suan-fa-by/

class Solution {
public:
    vector<int> majorityElement(vector<int>& nums) {
        vector<int> ans;
        if(nums.empty())    return ans;

        int cand1 = nums[0], cand2 = nums[0]; // 未说明数据范围，假装全是正数
        int count1 = 0, count2 = 0;

        for(int n: nums) {
            if(cand1 == n) {
                count1++;
            }
            else if(cand2 == n) {
                count2++;
            }
            else if(count1 == 0) {
                cand1 = n;
                count1 = 1;
            }
            else if(count2 == 0) {
                count2 = 1;
                cand2 = n;
            }
            else {
                count1--;
                count2--;
            }
        }
        
        count1 = count2 = 0;    // 计算候选人票数是否> n / 3
        for(int n: nums) {
            if(n == cand1)  count1++;
            else if(n == cand2) count2++;
        }
        if(count1 > nums.size() / 3)    ans.push_back(cand1);
        if(count2 > nums.size() / 3)    ans.push_back(cand2);
        return ans;
    }
};

