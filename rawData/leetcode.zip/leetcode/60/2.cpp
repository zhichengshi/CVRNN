//链接：https://leetcode-cn.com/problems/stack-of-plates-lcci/solution/xiao-bai-jie-fa-by-qiong-bxiao-nie/

class StackOfPlates {
 private:
    int size;
    vector<stack<int> > stack_sets;
public:
    StackOfPlates(int cap) {
        size=cap;
    }
    
    void push(int val) {
        if(size==0)
            return;
        if(stack_sets.size()==0||stack_sets[stack_sets.size()-1].size()==size)
        {
            stack<int> tmp;
            tmp.push(val);
            stack_sets.push_back(tmp);
        }
        else
        {
            stack_sets[stack_sets.size()-1].push(val);
        }
    }
    
    int pop() {
        if(stack_sets.size()==0)
            return -1;
        int ret=stack_sets[stack_sets.size()-1].top();
        stack_sets[stack_sets.size()-1].pop();
        if(stack_sets[stack_sets.size()-1].empty())
           {
                auto it=stack_sets.end();
                it--;
            stack_sets.erase(it);
        }
        return ret;
    }
    
    int popAt(int index) {
        if(stack_sets.size()==0||index<0||index>=stack_sets.size())
            return -1;
        int ret=stack_sets[index].top();
        stack_sets[index].pop();
        if(stack_sets[index].empty())
        {
            stack_sets.erase(stack_sets.begin()+index);
        }
        return ret;
    }
};
