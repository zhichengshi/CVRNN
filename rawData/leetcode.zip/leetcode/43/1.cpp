//链接：https://leetcode-cn.com/problems/kth-smallest-element-in-a-sorted-matrix/solution/c-er-fen-sou-suo-by-da-li-wang/

class Solution {
public:
    int bisearch(vector<int>& v, int t) {
        int l = 0;
        int r = v.size() - 1;
        while (l < r) {
            int m = l + (r - l + 1) / 2;
            if (v[m] <= t) {
                l = m;
            } else {
                r = m - 1;
            }
        }
        return l;
    }
    int kthSmallest(vector<vector<int>>& matrix, int k) {
        if (matrix.empty()) return -1;
        int R = matrix.size();
        int C = matrix[0].size();
        int low = matrix[0][0];
        int high = matrix[R - 1][C - 1];
        while (low < high) {
            int mid = low + (high - low) / 2;
            int count = 0;
            for (int i = 0; i < R; ++i) {
                if (matrix[i][0] <= mid) {
                    count += bisearch(matrix[i], mid) + 1;
                } else {
                    break;
                }
            }
            if (count < k) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        return high;
    }
};

