
//Populating Next Right Pointers in Each Node II
// 链接：https://leetcode-cn.com/problems/populating-next-right-pointers-in-each-node/solution/cpp-yan-du-you-xian-sou-suo-qing-song-jie-jue-by-x/
class Solution {
public:
    Node* connect(Node* root) {
        if (root == NULL ) return root;

        queue<Node*> q;
        q.push(root);

        while ( ! q.empty() ){
            int q_size = q.size();
            Node *tmp = NULL;
            while ( q_size-- ){
                Node* node = q.front();
                q.pop();
                if ( node == NULL ) continue;
                node->next = tmp;
                tmp = node;
                q.push(node->right);
                q.push(node->left);

            }
        }
        return root;
    }
};  
