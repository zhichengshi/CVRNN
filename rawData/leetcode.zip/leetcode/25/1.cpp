//Populating Next Right Pointers in Each Node II
//链接：https://leetcode-cn.com/problems/populating-next-right-pointers-in-each-node/solution/tian-chong-mei-ge-jie-dian-de-xia-yi-ge-you-ce-j-5/

class Solution {
public:
    Node* connect(Node* root) {
        if(root==NULL){
            return root;
        }
        queue<Node*> q;
        q.push(root);
        while(!q.empty()){
            int n = q.size();
            for(int i=1;i<=n;i++){
                Node* p=q.front();
                q.pop();
                if(i==n){
                    p->next=NULL;
                }else{
                    p->next=q.front();
                }
                if(p->left){
                    q.push(p->left);
                }
                if(p->right){
                    q.push(p->right);
                }
            }
        }
        return root;
    }
};

