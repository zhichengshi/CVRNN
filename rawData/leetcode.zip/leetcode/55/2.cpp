// Remove Duplicates from Sorted Array II   
// https://leetcode-cn.com/problems/remove-duplicates-from-sorted-array-ii/solution/zhi-jie-bian-li-yi-ci-ji-ke-by-luo-ben-zhu-xiao-ma/

int removeDuplicates(vector<int>& nums) 
{
	if (nums.size() <= 1)
		return nums.size();
	int current = 1;           //新数组中有效位置的最后一位，新加入的数据应当写到current+1
	for (int i = 2; i < nums.size();i++) //从第三位开始循环，前两位无论如何都是要加入新数组的
	{
		if (nums[i] != nums[current - 1])  //符合条件，加入新数组
		{
			current += 1;
			nums[current] = nums[i];
		}
	}
	return current+1;
}
