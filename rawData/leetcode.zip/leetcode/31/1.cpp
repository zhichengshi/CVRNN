//Sum Root to Leaf Numbers
//链接：https://leetcode-cn.com/problems/sum-root-to-leaf-numbers/solution/c-dfsdi-gui-by-zuo-10/

class Solution {
public:
    int sumNumbers(TreeNode* root) {
        if(!root) return 0;
        dfs(root,0);
        return sum;
    }
private:
    // 参数 preVal保存父节点的值
    void dfs(TreeNode* node,int preVal){
        if(!node) return;
        // 子节点累加
        node->val += 10 * preVal;
        if(!node->left && !node->right){
            sum += node->val;
        }
        dfs(node->left, node->val);
        dfs(node->right, node->val);
    }
private:
    int sum = 0;
};

