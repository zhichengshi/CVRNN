//Sum Root to Leaf Numbers
//链接：https://leetcode-cn.com/problems/sum-root-to-leaf-numbers/solution/c-dfsdi-gui-by-zuo-10/

class Solution {
public:
    int sumNumbers(TreeNode* root) {
        if(!root) return 0;
        return dfs(root,0);
    }
private:
    // 参数 preVal保存父节点的值
    int dfs(TreeNode* node,int preVal){
        if(!node){
            return 0;
        }
        // 子节点累加
        node->val += 10 * preVal;
        if(!node->left && !node->right){
            return node->val;
        }
        // 左子树叶子节点值
        int left = dfs(node->left, node->val);
        // 右子树叶子节点值
        int right = dfs(node->right, node->val);
        return left + right;
    }
};

