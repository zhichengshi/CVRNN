//链接：https://leetcode-cn.com/problems/rectangle-area/solution/223-ju-xing-mian-ji-by-boyxdoor-2/

class Solution {
public:
    int computeArea(int A, int B, int C, int D, int E, int F, int G, int H) {
        int x1 = max(A,E),x2 = min(C,G);
        int y1 = max(B,F),y2 = min(D,H);
        int area1 = (C-A)*(D-B);
        int area2 = (G-E)*(H-F);
        if(x1<x2&&y1<y2)
            return area1-(x2-x1)*(y2-y1)+area2;
        else
            return area1+area2;
    }
};

