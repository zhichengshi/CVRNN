//链接：https://leetcode-cn.com/problems/robot-in-a-grid-lcci/solution/dong-tai-gui-hua-by-wu-bin-cong-2/

class Solution {
	int dp[105][105];
public:
	vector<vector<int>> pathWithObstacles(vector<vector<int>>& obstacleGrid) {
		if (obstacleGrid.empty() || obstacleGrid[0].empty()) return {};
		int row = obstacleGrid.size();
		int col = obstacleGrid[0].size();
		if (obstacleGrid[0][0] == 1 || obstacleGrid[row - 1][col - 1] == 1) return {};
		
		memset(dp, 0, sizeof(dp));
		dp[0][0] = 1;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				if (i == 0 && j == 0) continue;
				if (obstacleGrid[i][j] == 1) continue;
				int up = i > 0 ? dp[i - 1][j] : 0;
				int down = j > 0 ? dp[i][j - 1] : 0;
				if (up == 0 && down == 0) continue;
				dp[i][j] = max(up, down) + 1;
			}
		}
		int x = row - 1, y = col - 1;
		if (dp[x][y] == 0) return {};
		vector<vector<int>> res;
		while (x != 0 || y != 0) {
			res.push_back({ x,y });
			int up = x > 0 ? dp[x - 1][y] : 0;
			int down = y > 0 ? dp[x][y - 1] : 0;
			if (up >= down) x--;
			else y--;
		}
		res.push_back({ 0,0 });
		reverse(res.begin(), res.end());
		return res;
	}
};

