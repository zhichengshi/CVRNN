//链接：https://leetcode-cn.com/problems/longest-harmonious-subsequence/solution/li-yong-map-by-li-xue-bing/

class Solution {
public:
    int findLHS(vector<int>& nums) {
        if(nums.size()<=1) return 0;

        map<int,int> count;
        for(auto num:nums)
        count[num]++;

        int max=0;
        for(auto c:count)
        if(count.count(c.first+1)&&max<c.second+count[c.first+1])
        max=c.second+count[c.first+1];

        return max;

    }
};

