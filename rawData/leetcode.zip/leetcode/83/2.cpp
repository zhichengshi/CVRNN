//链接：https://leetcode-cn.com/problems/baseball-game/solution/cchang-gui-ti-jie-by-shi-fen-fang-qi-zhong/

    int calPoints(vector<string>& ops) {
        int res = 0,addscr = 0,lastscr = 0;
            stack<int> points;
        for(auto itm : ops)
        {
            if(itm == "+")
            {
                lastscr = points.top();
                points.pop();
                addscr = lastscr + points.top();
                points.push(lastscr);
                points.push(addscr);
            }
            else if(itm == "D")
            {
                points.push(points.top() * 2);
            }
           else if(itm == "C")
            {
                points.pop();
            }
            else    
            {
                points.push(atoi(itm.c_str()));
            }
        }
        while(!points.empty())
        {
            res  += points.top(); 
            points.pop();
        }
        return res;
    }

