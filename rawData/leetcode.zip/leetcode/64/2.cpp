//链接：https://leetcode-cn.com/problems/words-frequency-lcci/solution/shi-yong-ji-he-unordered_map-by-oath-7/

class WordsFrequency {
private:
    unordered_map<string,int> dic;
public:
    WordsFrequency(vector<string>& book) {
        for(auto a:book)
        {
            dic[a]++;
        }
    }
    
    int get(string word) {
        return dic[word];
    }
};
