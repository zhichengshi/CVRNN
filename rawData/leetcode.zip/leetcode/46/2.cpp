//17. Letter Combinations of a Phone Number
//https://leetcode-cn.com/problems/letter-combinations-of-a-phone-number/solution/quan-pai-lie-de-di-gui-tong-fa-cshuang-100-by-jian/
class Solution {
public:
    vector<string> solvers;

    vector<string> letterCombinations(string digits) {
        if (digits.empty())
        {
            return{};
        }

        vector<string> letter_map = { "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz" };
        string solver;

        allsequence(digits, letter_map, 0, solver);

        return solvers;
    }

    void allsequence(string &digits, vector<string> &letter_map, int step, string &solver)
    {
        if (step == digits.size())
        {
            solvers.push_back(solver);
            return;
        }

        int index = digits[step] - '0' - 2;
        string s = letter_map[index];
        for (int i = 0; i < (int)s.size(); i++)
        {
            solver.push_back(letter_map[index][i]);
            allsequence(digits, letter_map, step + 1, solver);
            solver.erase(solver.end() - 1);
        }
    }
};
