//链接：https://leetcode-cn.com/problems/compress-string-lcci/solution/shuang-zhi-zhen-fa-qu-lian-xu-zi-fu-cpython-by-net/

string compressString(string S) {
    int N = S.length();
    string res;
    int i = 0;
    while (i < N) {
        int j = i;
        while (j < N && S[j] == S[i]) {
            j++;
        }
        res += S[i];
        res += to_string(j - i);
        i = j;
    }

    if (res.length() < S.length()) {
        return res;
    } else {
        return S;
    }
}
