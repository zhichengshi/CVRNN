//链接：https://leetcode-cn.com/problems/magic-index-lcci/solution/c-geng-jia-zhi-guan-de-er-fen-fa-by-zuo-10/

class Solution {
private:
    void binary_search(vector<int>& nums, int left, int right, int& ret){
        // 这里做一个剪枝
        if(ret != -1 && ret<left) return;
        if(left <= right){
            int mid = left + (right - left) / 2;
            // 如果找到目标的索引，需要尝试能否找到更小的索引值
            if(nums[mid] == mid){
                if(ret == -1) ret = mid;
                else if(mid < ret) ret = mid;
                binary_search(nums, left, mid - 1, ret);
            // 如果mid不符合要求，则需要在mid两边继续查找
            }else{
                binary_search(nums, left, mid - 1, ret);
                binary_search(nums, mid + 1, right, ret);
            }
        }
    }
public:
    int findMagicIndex(vector<int>& nums) {
        // 2. 二分法
        int ret = -1;
        binary_search(nums, 0, nums.size()-1, ret);
    }
};

