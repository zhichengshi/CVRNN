//链接：https://leetcode-cn.com/problems/combination-sum-iv/solution/dong-tai-gui-hua-ji-yi-hua-sou-suo-by-docker-2/
class Solution {
public:
    int count;
    int combinationSum4(vector<int>& candidates, int target) {
        dfs(target,target,candidates);
        return count;
    }
    void dfs(int target,int remain,vector<int>& candidates){
        if(remain<0)return;
        if(remain==0){
            count++;
            return;
        }
        for(int i = 0;i<candidates.size();i++){
            dfs(target,remain - candidates[i],candidates);
        }
    }
};

