//链接：https://leetcode-cn.com/problems/combination-sum-iv/solution/dong-tai-gui-hua-ji-yi-hua-sou-suo-by-docker-2/

class Solution {
public:
    vector<long long> temp;
    long long count;
    int combinationSum4(vector<int>& candidates, int target) {
        temp = vector(target+1,-1ll);
        for(int i=1;i<=target;i++){
            count=0;
            dfs(i,i,candidates);
            temp[i]=count;
        }
        return count;
    }
    void dfs(int target,int remain,vector<int>& candidates){
        if(remain<0)return;
        if(temp[remain]!=-1){//如果还要凑的数已经算过了则加上当前方案数之和返回即可。
            count+=temp[remain];
            count%=INT_MAX;//防止超出整数的表示范围
            return;
        }
        if(remain==0){
            count++;
            return;
        }
        for(int i = 0;i<candidates.size();i++){
            dfs(target,remain - candidates[i],candidates);
        }
    }
};
