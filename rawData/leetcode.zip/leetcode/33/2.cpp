


//链接：https://leetcode-cn.com/problems/partition-list/solution/da-xiao-fen-liang-bian-by-mjc199252/

class Solution {
public:
    ListNode* partition(ListNode* head, int x) {
         ListNode* big = new ListNode(-1);
         ListNode* let = new ListNode(-1);
         ListNode *ret = let,*da = big;
         while(head != NULL){
             if(head->val < x){
                 let->next = head;
                 let = let->next;
             }else{
                 big->next = head;
                 big = big->next;
             }
             head = head->next;
         }
         big->next = NULL;
         let->next = da->next;
         return ret->next;
    }
};

