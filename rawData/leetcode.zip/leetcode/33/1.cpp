//Partition List  
//链接：https://leetcode-cn.com/problems/partition-list/solution/czhi-jie-fen-liang-bian-by-prena/


class Solution {
public:
    ListNode* partition(ListNode* head, int target) {
        ListNode *small=new ListNode(-1);
        ListNode *big=new ListNode(-1);
        ListNode *res=small,*mid=big;
        while(head!=NULL){
            if(head->val<target){
                small->next=head;
                small=small->next;
            }
            else{
                big->next=head;
                big=big->next;
            }
            head=head->next;
        }
        big->next=NULL;//若最后为小，则必须将big的next转移掉
        small->next=mid->next;
        return res->next;
    }
};

