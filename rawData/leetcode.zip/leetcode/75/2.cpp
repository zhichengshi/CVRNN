//链接：https://leetcode-cn.com/problems/min-stack-lcci/solution/c-fu-zhu-zhan-by-sysuzyc/

class MinStack {
public:
    /** initialize your data structure here. */
    MinStack() {
        
    }
    
    void push(int x) {
        main_stk.push(x);
        if(help_stk.empty()) help_stk.push(x);
        else {
            if(x < help_stk.top()){
                help_stk.push(x);
            }else{
                int temp = help_stk.top();
                help_stk.push(temp);
            }
        }
    }
    
    void pop() {
        main_stk.pop();
        help_stk.pop();
    }
    
    int top() {
        return main_stk.top();
    }
    
    int getMin() {
        return help_stk.top();
    }
private:
    stack<int> main_stk;
    stack<int> help_stk;
};

