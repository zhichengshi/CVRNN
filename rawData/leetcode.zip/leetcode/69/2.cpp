//链接：https://leetcode-cn.com/problems/element-appearing-more-than-25-in-sorted-array/solution/shuang-zhi-zhen-bian-li-shu-zu-yi-ci-de-dao-chu-xi/

class Solution {
public:
    int findSpecialInteger(vector<int>& arr) {
        int i = 0, j = 0;
        int n = arr.size();
        int limit = n >> 2;
        int count = 0;
        // 看似两个while，实际因为双指针，对每个元素只会遍历一次
        while(i < n){
            while(j < n && arr[i] == arr[j]){
                count++;
                j++;
            }
            if(count > limit){
                return arr[i];
            }else{
                i = j + 1;
                j = i;
                count = 0;
            }
        }
        return arr[i];
    }
};

