//链接：https://leetcode-cn.com/problems/missing-two-lcci/solution/2bian-lei-jia-qiu-jie-bu-pai-xu-by-lxy-29/

class Solution {
public:
    vector<int> missingTwo(vector<int>& nums) {
        int sum = 0;
        for (auto e : nums) {  // 所有元素求和
            sum += e;
        }

        int nr = nums.size() + 2;
        int sumOfTwo = (1+nr)*nr/2 - sum;  // 计算两个缺失元素和：sum(1..N) - sum(nums)
        int threshold = (sumOfTwo) / 2;

        sum = 0;
        for (auto e : nums) {
            if (e <= threshold) {  // 小于等于threshold的元素求和
                sum += e;
            }
        }

        vector<int> res;
        res.push_back((1+threshold)*(threshold)/2 - sum); // 第一个缺失的数字：sum(1..threshold) - sum(nums中小于等于threshold的元素)
        res.push_back(sumOfTwo-res[0]);   // 相减直接得到 第二个缺失的数字

        return res;
    }
};

