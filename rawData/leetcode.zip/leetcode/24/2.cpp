//链接：https://leetcode-cn.com/problems/exclusive-time-of-functions/solution/c-zhan-jie-fa-by-da-li-wang-6/

class Solution {
public:
    vector<string> split(const string& s, char sp) {
        vector<string> v;
        string t;
        for (auto c : s) {
            if (c == sp) {
                if (!t.empty()) {
                    v.push_back(t);
                    t.clear();
                }
            } else {
                t += c;
            }
        }
        if (!t.empty()) v.push_back(t);
        return v;
    }
    vector<int> exclusiveTime(int n, vector<string>& logs) {
        stack<int> st;
        vector<int> res(n, 0);
        int prev_t = -1;
        for (auto& s : logs) {
            auto items = split(s, ':');
            int id = stoi(items[0]);
            int t = stoi(items[2]);
            ++res[id];
            if (!st.empty() && prev_t != -1) {
                res[st.top()] += t - prev_t - 1;
            }
            if (items[1] == "start") {
                st.push(id);
            } else {
                st.pop();
            }
            prev_t = t;
        }
        return res;
    }
};

