
//链接：https://leetcode-cn.com/problems/design-twitter/solution/leetcode355-mian-xiang-guo-cheng-zui-da-de-kge-shu/

typedef pair<int, int> PII;

class Twitter {
private:
    unordered_map<int, unordered_set<int>> followers_;  // id - followers
    unordered_map<int, vector<PII>> contents_;  // id - {time, twitterId}
    int time = 0;
    
public:
    Twitter() {
        followers_.clear();
        contents_.clear();
        time = 0;
    }
    
    void postTweet(int userId, int tweetId) {
        contents_[userId].push_back({time++, tweetId});
    }
    
    vector<int> getNewsFeed(int userId) {  // userId不存在则返回空数组
        priority_queue<PII, vector<PII>, greater<PII>> q;
        
        for (PII item : contents_[userId]) {   // 先考虑自己
            q.push(item);
            if (q.size() > 10) q.pop();
        }
        
        for (int followeeId : followers_[userId]) {   // 再考虑他人 
            for (PII item : contents_[followeeId]) {
                q.push(item);
                if (q.size() > 10) q.pop();
            }
        }
        vector<int> ret;
        while (!q.empty()) {
            ret.push_back(q.top().second);
            q.pop();
        }
        reverse(ret.begin(), ret.end());
        return ret;
    }

    void follow(int followerId, int followeeId) {
        if (followerId == followeeId) return;
        followers_[followerId].insert(followeeId);
    }
    
    void unfollow(int followerId, int followeeId) {
        if (!followers_[followerId].count(followeeId)) return;
        followers_[followerId].erase(followeeId);
    }
};

