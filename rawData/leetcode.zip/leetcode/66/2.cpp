//链接：https://leetcode-cn.com/problems/pile-box-lcci/solution/dfsji-yi-hua-shu-zu-by-hw_wt/

typedef struct Node {
    int x;
    int y;
    int z;
    Node(int i, int j, int k) : x(i), y(j), z(k) {}
} Node;

bool cmpFunc(Node& l, Node& r)
{
    if (l.x < r.x) {
        return true;
    } 
    if (l.x == r.x) {
        if (l.y > r.y) {
            return true;
        }
        if (l.y == r.y) {
            return l.z > r.z;
        } 
    }
    return false;
}

class Solution {
public:
    /*
    思路  
    --DP 其实跟回溯差不多，类似求上升子序列，设定基点位置，求每个基点位置的满足条件数
    */
    int pileBox(vector<vector<int>>& box) {
        int n = box.size();
        vector<Node> boxNode;
        vector<vector<int>> mem(n + 1, vector<int>(n, -1));
        for (int i = 0; i < n; i++) {
            boxNode.push_back(Node(box[i][0], box[i][1], box[i][2]));
        }
        sort(boxNode.begin(), boxNode.end(), cmpFunc);

        vector<int> dp(n, 0);
        dp[0] = boxNode[0].z;
        int res = dp[0];
        for (int i = 1; i < n; i++) {
            int maxval = 0;
            for (int j = 0; j < i; j++) {
                if (boxNode[i].y > boxNode[j].y && boxNode[i].z > boxNode[j].z) {
                    maxval = max(maxval, dp[j]);
                }
            }
            dp[i] = maxval + boxNode[i].z;
            res = max(res, dp[i]);
        }
        return res;
    }
};

