//链接：https://leetcode-cn.com/problems/longest-absolute-file-path/solution/yong-zhan-xiang-xi-mo-ni-liao-yi-xia-by-wf_csu/

class Solution {
public:
    typedef pair<string,int> P;
    int lengthLongestPath(string input) {
        int n = input.size(),lastdeep=-1,start=0,curlen=0,res=0;
        stack<P>s;
        for(int i=0;i<=n;i++){
            if(i==n || input[i]=='\n'){
                string path = input.substr(start,i-start);  //一层路径
                int j=0;
                while(j<i-start && path[j]=='\t')j++;   //根据\t的数量判断在第几层
                start = i + 1;
                while(!s.empty() && j<=lastdeep){       //当前层数小于等于上一层深度弹栈,当前长度减去对应的目录长度
                    curlen -= s.top().first.size();
                    s.pop();
                    if(!s.empty())lastdeep = s.top().second;
                }
                lastdeep = j;
                string dir = path.substr(j);        //否则将当前目录进栈
                s.push({dir,j});
                curlen+=dir.size();
                if(dir.find('.')!=-1)res = max(res,curlen+j);   //碰到'.'更新答案
            }   
        
        }
        return res;
    }
};
