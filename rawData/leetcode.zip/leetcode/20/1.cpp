//链接：https://leetcode-cn.com/problems/binary-search-tree-iterator/solution/zi-ji-li-jie-de-si-lu-shuo-ming-yong-cshi-xian-by-/

class BSTIterator {
public:
    vector <TreeNode *> Vec;
    BSTIterator(TreeNode *root) {
        while (root != nullptr) {
            Vec.push_back(root);
            root = root -> left;
        }
        return;
    }
    
    /** @return the next smallest number */
    int next() {
        TreeNode *tmp = Vec.back();
        int ret = tmp -> val;
        Vec.pop_back();
        TreeNode *res = tmp -> right;
        while(res != nullptr) {
            Vec.push_back(res);
            res = res -> left;
        }
        return ret;
    }
    
    /** @return whether we have a next smallest number */
    bool hasNext() {
        if (!Vec.empty()) {
            return true;
        }
        return false;
    }
};
