//链接：https://leetcode-cn.com/problems/binary-search-tree-iterator/solution/c-er-cha-sou-suo-shu-die-dai-qi-zhan-jun-tan-by-zu/

class BSTIterator {
public:
    BSTIterator(TreeNode* root) {
        while(root){
            st.push(root);
            root = root->left;
        }
    }
    
    /** @return the next smallest number */
    int next() {
        TreeNode* curNode = st.top(); st.pop();
        int ret = curNode->val;
        curNode = curNode->right;
        while(curNode){
            st.push(curNode);
            curNode = curNode->left;
        }
        return ret;
    }
    
    /** @return whether we have a next smallest number */
    bool hasNext() {
        return !st.empty();
    }
private:
    stack<TreeNode*> st;
};

