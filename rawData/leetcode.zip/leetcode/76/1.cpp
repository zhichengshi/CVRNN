//链接：https://leetcode-cn.com/problems/volume-of-histogram-lcci/solution/dan-diao-zhan-wei-hu-ji-shui-qu-jian-by-wnjxyk/

class Solution {
public:
    int trap(vector<int>& height) {
        stack<int> S; 
        int ans = 0, n = height.size();
        
        for (int i = 0; i < n; i++){
            int h = height[i];
            while(!S.empty() && height[S.top()] <= h){
                int last = height[S.top()]; S.pop();
                if (!S.empty()) ans += (i - S.top() - 1) * (min(h, height[S.top()]) - last);
            }
            S.push(i);
        }

        return ans;
    }
};

