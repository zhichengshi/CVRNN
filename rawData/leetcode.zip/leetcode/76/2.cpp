//链接：https://leetcode-cn.com/problems/volume-of-histogram-lcci/solution/c-dan-diao-zhan-mian-shi-ti-1721-zhi-fang-tu-de-sh/

class Solution {
public:
    int trap(vector<int>& height) {
        if (!height.size()) return 0;
        stack<int> stx;
        stack<int> sty;
        int result = 0;
        for (int i = 0; i < height.size(); ++i) {
            int dlt = 0;
            while (!sty.empty() && height[i] >= sty.top()) {
                int x = stx.top(), y = sty.top();
                stx.pop();
                sty.pop();
                result += (i-x-1) * (y-dlt);
                dlt = y;
            }
            if (!sty.empty()) result += (i-stx.top()-1) * (height[i]-dlt);
            stx.push(i);
            sty.push(height[i]);
        }
        return result;
    }
};
