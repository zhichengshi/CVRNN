//链接：https://leetcode-cn.com/problems/find-positive-integer-solution-for-a-given-equation/solution/-zhao-chu-gei-ding-fang-cheng-de-zheng-zheng-shu-j/

class Solution {
public:
    vector<vector<int>> findSolution(CustomFunction& customfunction, const int z) {
        vector<vector<int>> ans;
        for (int i = 1, j = 1000; i <= 1000 && 1 <= j;) {
            const int val = customfunction.f(i, j);
            if (val == z) {
                ans.push_back({i, j});
                ++i, --j;
            } else if (val < z) {
                ++i;
            } else {
                --j;
            }
        }
        return ans;
    }
};

