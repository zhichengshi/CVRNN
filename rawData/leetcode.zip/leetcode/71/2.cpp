//链接：https://leetcode-cn.com/problems/find-positive-integer-solution-for-a-given-equation/solution/shuang-zhi-zhen-da-biao-fen-xi-by-xyqkoala/

class Solution {
public:
    vector<vector<int>> findSolution(CustomFunction& cf, int z) {
        int x = 1;
        int y = 1000;
        vector<vector<int>> re;
        while(x<1001 && y>0){
            int fz = cf.f(x,y);
            if(fz>z) --y;
            else if(fz <z) ++x;
            else{
                re.push_back({x,y});
                --y;
            }
        }
        return re;
    }
};

