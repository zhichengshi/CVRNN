//链接：https://leetcode-cn.com/problems/minimum-height-trees/solution/tuo-bu-pai-xu-by-liyiping/


class Solution {
public:
    vector<int> findMinHeightTrees(int n, vector<vector<int>>& edges) {
        if(n==1 && edges.size()==0)return {0};//面向测试用例编程
        vector<int>res;
        vector<int>indegree(n);
        vector<vector<int>> graph(n,vector<int>());
        queue<int>q;

        //构造临接表
        for(auto item:edges){
            graph[item[0]].push_back(item[1]);
            graph[item[1]].push_back(item[0]);
        }

        //构造入度表
        for(auto item:edges){
            indegree[item[0]]++;
            indegree[item[1]]++;
        }

        //将叶子节点，也就是入度数为1的点加入队列
        for(int i=0;i<n;i++){
            if(indegree[i]==1)q.push(i);
        }
        while(n>2){
            int count=q.size();
            n-=count;
            //每次将所有的叶子节点去除，并且将新的叶子节点加入队列
            while(count--){
                int item=q.front();
                q.pop();
                int size=graph[item].size();
                for(int i=0;i<size;i++){
                    //既然是无向边，那么要将两个节点的入度数都要减一
                    --indegree[item];
                    --indegree[graph[item][i]];
                    //将新的叶子节点入队
                    if(indegree[graph[item][i]]==1)q.push(graph[item][i]);
                }
            }
        }

        //此时队列中的节点便是要返回的值，不论是一个还是两个节点。
        while(!q.empty()){
            res.push_back(q.front());
            q.pop();
        }
        
        return res;
    }
};

