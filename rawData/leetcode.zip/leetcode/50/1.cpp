//Subsets II  
//链接：https://leetcode-cn.com/problems/subsets-ii/solution/90-zhi-xing-yong-shi-nei-cun-xiao-hao-ji-bai-liao-/

class Solution {
public:
    vector<vector<int>> subsetsWithDup(vector<int>& nums) {
        sort(nums.begin(), nums.end());
        vector<vector<int>> res;
        vector<bool> table(nums.size(), false);
        vector<int> combination;
        getCombination(res, nums, combination, table, 0);
        return res;
    }

    void getCombination(vector<vector<int>> &res, vector<int>& nums, vector<int> &combination, vector<bool> &table, int idx){
        if(combination.size() > res.size()){
            return;
        }else{
            res.push_back(combination);
        }
        for(int i = idx; i < nums.size(); ++i){
            if(table[i] == true) continue;
            if(i > 0 && nums[i] == nums[i-1] && !table[i-1]) continue;
            combination.push_back(nums[i]);
            table[i] = true;
            getCombination(res, nums, combination, table, i+1);
            combination.pop_back();
            table[i] = false;
        }
    }
};

