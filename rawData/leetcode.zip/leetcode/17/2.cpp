//链接：https://leetcode-cn.com/problems/accounts-merge/solution/dfsbing-cha-ji-by-aegeaner-2/

class Solution {
private:
    unordered_map<string, string> dict;
    unordered_map<string, vector<string>> graph;
    unordered_map<string, bool> visited;
    vector<vector<string>> res;
public:
    void init(vector<vector<string>>& accounts) {
        for(auto& account: accounts) {
            int n = account.size();
            string name = account[0];
            for(int i=1; i<n; i++) {
                dict[account[i]] = name;
                for(int j=i+1; j<n; j++) {
                    graph[account[i]].push_back(account[j]);
                    graph[account[j]].push_back(account[i]);
                }
            }
        }
    }
    
    vector<vector<string>> accountsMerge(vector<vector<string>>& accounts) {
        init(accounts);
        int n = dict.size();

        for(auto& p: dict) {
            if(!visited[p.first]) {
                vector<string> cur;
                cur.push_back(p.second);
                dfs(p.first, cur);
                sort(cur.begin(), cur.end());
                res.push_back(cur);
            }
        }
        return res;
    }
    
    void dfs(string email, vector<string>& cur) {
        visited[email] = true;
        cur.push_back(email);
        for(auto& e: graph[email]) {
            if(!visited[e]) {
                dfs(e, cur);
            }
        }
    }
};

