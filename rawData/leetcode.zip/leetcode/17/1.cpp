//链接：https://leetcode-cn.com/problems/accounts-merge/solution/jian-dan-de-dfsxun-zhao-lian-tong-tu-jie-fa-xiao-l/

class Solution {
public:
    void dfs(string &curNode, unordered_map<string, unordered_set<string>> &graph, vector<string> &curRecord) {
        if (visited.count(curNode)) {
            return;
        }
        visited.insert(curNode);
        curRecord.emplace_back(curNode);
        for (auto email : graph[curNode]) {
            if (!visited.count(email)) {
                dfs(email, graph, curRecord);
            }
        }
    }
    vector<vector<string>> accountsMerge(vector<vector<string>>& accounts) {
        unordered_map<string, string> emailToNameMap;
        unordered_map<string, unordered_set<string>> graph;

        // 建图
        for (auto account : accounts) {
            string name = account[0];
            //printf("cur record: %s -- size=%d\n", name.c_str(), account.size());
            for (int i = 1; i < account.size(); i++) {
                // 记录email->name的映射表
                emailToNameMap[account[i]] = name;
                // 建图, 邻接表
                for (int j = 1; j < account.size(); j++) {
                    graph[account[i]].insert(account[j]);
                }
            }
        }

        for (auto node : graph) {
            if (visited.count(node.first)) {
                continue;
            }
            string email = node.first;
            string name = emailToNameMap[email];
            vector<string> onerecord;
            onerecord.emplace_back(name);
            dfs(email, graph, onerecord);
            sort(onerecord.begin(), onerecord.end());
            ans.emplace_back(onerecord);
        }
        return ans;
    }
private:
    unordered_set<string> visited;
    vector<vector<string>> ans;
};

