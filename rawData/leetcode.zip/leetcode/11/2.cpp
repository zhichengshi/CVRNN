//链接：https://leetcode-cn.com/problems/search-a-2d-matrix-ii/solution/240-sou-suo-er-wei-ju-zhen-ii-suo-jian-kong-jian-b/

class Solution {
public:
    bool searchMatrix(vector<vector<int>>& matrix, int target) {
        //边界值
        if (matrix.size() == 0 || matrix[0].size() == 0) {
            return false;
        }
        int row = matrix.size(), col = matrix[0].size();
        int i = 0, j = col - 1;
        while (i < row && j >= 0) {
            if (matrix[i][j] == target) {
                return true;
            } else if (matrix[i][j] < target) {
                ++i;
            } else if (matrix[i][j] > target) {
                --j;
            }
        }
        return false;
    }
};

