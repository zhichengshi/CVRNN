//链接：https://leetcode-cn.com/problems/shortest-supersequence-lcci/solution/c-si-lu-dai-ma-jian-ji-by-zhao-zi-ji/

class Solution {
public:
    vector<int> shortestSeq(vector<int>& big, vector<int>& small) {
        int n = small.size();
        vector<int> vis(n,0);
        int b = big.size();
        int l = 0,r = 0,cnt = 0;
        unordered_map<int,int> m;
        for(int i=0;i<n;i++)m[small[i]]=i;
        int ansl=-1,ansr = -1,len = INT_MAX;
        while(r<b){
            if(m.count(big[r])==0){r++;continue;}
            if(vis[m[big[r]]]==0)cnt++;
            vis[m[big[r]]]++;
            if(cnt==n){
                while(l<=r){
                    if(m.count(big[l])==0){l++;continue;}
                    vis[m[big[l]]]--;
                    if(vis[m[big[l]]]==0){
                        if(len>r-l+1){
                            ansl = l;ansr=r;
                            len = r-l+1;
                        }
                        cnt--;
                        l++;
                        break;
                    }
                    l++;
                }
            }
            r++;
        }
        vector<int> ans;
        if(len<INT_MAX){ans.push_back(ansl);ans.push_back(ansr);}
        return ans;
    }
};

