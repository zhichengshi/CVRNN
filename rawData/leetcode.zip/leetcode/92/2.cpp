//链接：https://leetcode-cn.com/problems/construct-string-from-binary-tree/solution/chun-c-by-hua-jia-wang-tie-nan-32/

class Solution {
public:
    string tree2str(TreeNode* t) {
        if (nullptr == t)
        {
            return "";
        }

        const string s = std::to_string(t->val);
        const string left = tree2str(t->left);
        const string right = tree2str(t->right);

        if (nullptr == t->left && nullptr == t->right)
        {
            return s;
        }

        if (nullptr == t->right)
        {
            return s + "(" + left + ")";
        }

        return s + "(" + left + ")" + "(" + right + ")";
    }
};

