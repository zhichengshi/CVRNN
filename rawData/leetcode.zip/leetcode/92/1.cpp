//链接：https://leetcode-cn.com/problems/construct-string-from-binary-tree/solution/ti-mu-miao-shu-you-wen-ti-by-amazingt/

class Solution {
public:
    string tree2str(TreeNode* t) {
        string res;
        res = helper(t);
        //return res;
        //cout << res;
        return res;
    }
    string helper(TreeNode* t){
        string res = "";
        if(t == NULL)
            return "";
        //char a = 'a'+(t->val);
        res+=to_string(t->val);
        //cout <<res;
        string left = helper(t->left);
        string right = helper(t->right);
        if(!t->left && !t->right)
            res+="";
        else if(t->left && !t->right)
            res =  res+'('+left+')';
        else if(t->right &&!t->left)
            res = res+"()"+ '('+right+')';
        else res = res+'('+left+')'+'('+right+')';
        return res;
    }
};

