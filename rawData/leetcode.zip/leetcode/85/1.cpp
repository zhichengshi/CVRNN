//链接：https://leetcode-cn.com/problems/duplicate-zeros/solution/xiao-bai-shua-ti-fu-xie-ling-by-buptra_prism/

class Solution {
public:
    void duplicateZeros(vector<int>& arr) {
        int len = arr.size();
        for (int i = 0; i < len; i++) {
            if (arr[i] == 0) {
                arr.insert(arr.begin() + i, 0);
                arr.pop_back();
                i++;
            }
        }
    }
};
