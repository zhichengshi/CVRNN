//链接：https://leetcode-cn.com/problems/er-cha-sou-suo-shu-de-hou-xu-bian-li-xu-lie-lcof/solution/er-cha-sou-suo-shu-zhi-hou-xu-bian-li-jian-cha-by-/

class Solution {
public:

    bool verifyPostorder(vector<int>& postorder) {
        return ok(postorder, 0, postorder.size()-1);
    }
    bool ok(vector<int>& p, int i, int j){
        if(j-i <= 1) return true;
        int ri=j-1,rj=ri,li=i,lj=li-1;

        while(p[lj+1]<p[j]&&lj<j){lj++;}
        
        ri=lj+1;
        for(int k=ri; k<=rj; k++){
            if(p[k]<p[j]) return false;
        }
        
        return ok(p, li, lj) && ok(p, ri, rj);
    }
 };

