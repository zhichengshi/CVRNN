//链接：https://leetcode-cn.com/problems/er-cha-sou-suo-shu-de-hou-xu-bian-li-xu-lie-lcof/solution/di-gui-by-alanpeng/

class Solution {
public:
    bool verifyPostorder(vector<int>& postorder) {
        if(postorder.size() < 2) return true;
        return isPostorder(postorder, 0, postorder.size()-1);
    }

    //后序遍历最后节点为根节点，二叉搜索树左子树都小于根节点，右子树都大于根节点，因此可以找出左子树和右子树理论分界处进行判断，再左右子树递归判断
    bool isPostorder(vector<int>& postorder, int start, int end){
        if(start >= end) return true;
        int i=start;
        while(postorder[i] < postorder[end])    //左子树
            i++;

        int bound = i;      //左右子树理论分界点
        for(; i<end; i++)   //右子树应该小于根节点，否则不是二叉搜索树
        {
            if(postorder[i] < postorder[end]) return false;
        }
        return isPostorder(postorder, start, bound-1) && isPostorder(postorder, bound, end-1); //递归判断左右子树
    }
};
