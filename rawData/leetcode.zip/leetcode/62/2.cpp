//链接：https://leetcode-cn.com/problems/animal-shelter-lcci/solution/shuang-dui-lie-by-cxxjxb/

class AnimalShelf {
public:
    AnimalShelf() {

    }
    
    void enqueue(vector<int> animal) {
        if(animal[1] == 0){
            cats.push(animal[0]);
        }
        if(animal[1] == 1){
            dogs.push(animal[0]);
        }
    }
    
    vector<int> dequeueAny() {
        vector<int> result;
        if(cats.empty()&&dogs.empty()){
            return empty_;
        }else if(cats.empty()&&!dogs.empty()){
            result =  dequeueDog();
        }else if(!cats.empty()&&dogs.empty()){
            result =  dequeueCat();
        }else if(cats.front() < dogs.front()){
            result = dequeueCat();
        }else{
            result = dequeueDog();
        }
        return result;
    }
    
    vector<int> dequeueDog() {
        if(dogs.empty()){
            return empty_;
        }
        int dog = dogs.front();
        dogs.pop();
        vector<int> result;
        result.push_back(dog);
        result.push_back(1);
        return result;
    }
    
    vector<int> dequeueCat() {
        if(cats.empty()){
            return empty_;
        }
        int cat = cats.front();
        cats.pop();
        vector<int> result;
        result.push_back(cat);
        result.push_back(0);
        return result;
    }
    queue<int> cats;
    queue<int> dogs;
    vector<int> empty_{-1,-1};
};

