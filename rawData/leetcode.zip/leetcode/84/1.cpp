//链接：https://leetcode-cn.com/problems/sparse-similarity-lcci/solution/bao-li-cai-biao-cheng-qia-jing-du-by-lightcml/

class Solution {
    const double eps=1e-12;
    map<int,vector<int> > A;
    map<pair<int,int>,bool> Mark;
    vector<string> Ans;
    void Put(int a,int b,vector<vector<int> > &v)
    {
        int s=0;
        int n=v[a].size();
        int m=v[b].size();
        if (!n || !m) return ;
        for (int i=0,j=0;i<n && j<m;)
            if (v[a][i]==v[b][j]) ++s,++i,++j;
            else if (v[a][i]<v[b][j]) ++i;
            else ++j;
        if (!s) return ;
        double ans=1.0*s/(n+m-s);
        //printf("%d %d %.4lf\n",a,b,ans);
        string ss;
        string aa;
        if (!a) aa="0";
        else
        {
            while (a)
            {
                aa.push_back('0'+a%10);
                a/=10;
            }
        }
        reverse(aa.begin(),aa.end());
        ss=aa;
        aa.clear();
        if (!b) aa="0";
        else
        {
            while (b)
            {
                aa.push_back('0'+b%10);
                b/=10;
            }
        }
        reverse(aa.begin(),aa.end());
        ss.push_back(',');
        ss+=aa;
        ss+=": ";
        int vv=ans;
        double vvv=ans-vv;
        aa.clear();
        if (!vv) aa="0";
        else
        {
            while (vv)
            {
                aa.push_back('0'+vv%10);
                vv/=10;
            }
        }
        reverse(aa.begin(),aa.end());
        ss+=aa;
        ss.push_back('.');
        vvv*=10000;
        int vvvv=vvv;
        vvv*=10;
        int t=vvv;
        vvv-=t;
        t%=10;
        vvv-=t;
        if (t>5) ++vvvv;
        else if (t==5)
        {
            if (vvvv>eps) ++vvvv;
        }
        aa.clear();
        for (int i=1;i<=4;++i)
        {
            aa.push_back(vvvv%10+'0');
            vvvv/=10;
        }
        reverse(aa.begin(),aa.end());
        ss+=aa;
        Ans.push_back(ss);
    }
public:
    vector<string> computeSimilarities(vector<vector<int>>& docs) {
        int n=docs.size();
        for (int i=0;i<n;++i) sort(docs[i].begin(),docs[i].end());
        /*暴力的部分
        for (int i=0;i<n;++i)
            for (int j=i+1;j<n;++j)
                Put(i,j,docs);
        */
        for (int i=0;i<n;++i)
        {
            int m=docs[i].size();
            for (int j=0;j<m;++j) A[docs[i][j]].push_back(i);
        }
        vector<int> s;
        for (auto it:A)
        {
            s=it.second;
            int mm=s.size();
            for (int i=0;i<mm;++i)
                for (int j=i+1;j<mm;++j)
                {
                    pair<int,int> v=make_pair(s[i],s[j]);
                    if (!Mark[v])
                    {
                        Put(s[i],s[j],docs);
                        Mark[v]=true;
                    }
                }
        }
        return Ans;
    }
};

