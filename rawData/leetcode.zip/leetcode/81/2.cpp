//链接：https://leetcode-cn.com/problems/pascals-triangle-ii/solution/119yang-hui-san-jiao-2de-python3he-cjie-fa-by-bian/

class Solution {
public:
    vector<int> getRow(int rowIndex) {
        vector<int> res;
        if(rowIndex<0)
            return res;
        res.push_back(1);
        for(int i=0; i<rowIndex; ++i)
            res.push_back(static_cast<int>(double(res[i])*(rowIndex-i)/(i+1))); //注意res[i]不进行类型转换会造成结果overflow
        return res;
    }
};

