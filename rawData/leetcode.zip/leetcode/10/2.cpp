//链接：https://leetcode-cn.com/problems/bulb-switcher/solution/you-jian-dan-li-zi-tui-li-rong-yi-li-jie-by-fall12/

int bulbSwitch(int n) {
    int index=1;
    for(int i=1; i<=n; i++) {
        if(index*index ==i) {
            index++;
            if(index*index>n) break;
        }
    }
    return index-1;
}

