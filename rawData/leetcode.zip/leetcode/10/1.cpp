//链接：https://leetcode-cn.com/problems/bulb-switcher/solution/wei-shi-yao-ping-fang-shu-yi-ding-shi-liang-zhao-d/

int bulbSwitch(int n) {
    if(n==1)
        return 1;
    int result = 1;
    while(true) {
        if(result*result>n)
            break;
        result++;
    }
    return result-1;
}
