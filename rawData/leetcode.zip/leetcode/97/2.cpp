//链接：https://leetcode-cn.com/problems/robot-return-to-origin/solution/cxiang-xi-jian-dan-zuo-fa-by-youlookdeliciousc/

class Solution {
public:
    bool judgeCircle(string moves) {
        int h = 0, v = 0; //v: vertical h: horizontal
        for(auto i : moves){
            if(i == 'U')    ++ v;
            else if(i == 'D')   -- v;
            else if(i == 'R')   ++ h;
            else    -- h;
        }
        return h == 0 && v == 0? true : false; //当垂直和水平位移为0时，说明机器人返回原点
    }
};

